package javazoom.spi.vorbis.sampled.file;

import java.util.Map;
import javax.sound.sampled.AudioFileFormat.Type;
import javax.sound.sampled.AudioFormat;
import org.tritonus.share.sampled.file.TAudioFileFormat;

public class VorbisAudioFileFormat
  extends TAudioFileFormat
{
  public VorbisAudioFileFormat(AudioFileFormat.Type paramType, AudioFormat paramAudioFormat, int paramInt1, int paramInt2, Map paramMap)
  {
    super(paramType, paramAudioFormat, paramInt1, paramInt2, paramMap);
  }
  
  public Map properties()
  {
    return super.properties();
  }
}
