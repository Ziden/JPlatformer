package javazoom.spi.vorbis.sampled.file;

import javax.sound.sampled.AudioFormat.Encoding;

public class VorbisEncoding
  extends AudioFormat.Encoding
{
  public static final AudioFormat.Encoding VORBISENC = new VorbisEncoding("VORBISENC");
  
  public VorbisEncoding(String paramString)
  {
    super(paramString);
  }
}
