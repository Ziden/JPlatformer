package javazoom.spi.vorbis.sampled.file;

import javax.sound.sampled.AudioFileFormat.Type;

public class VorbisFileFormatType
  extends AudioFileFormat.Type
{
  public static final AudioFileFormat.Type VORBIS = new VorbisFileFormatType("VORBIS", "ogg");
  public static final AudioFileFormat.Type OGG = new VorbisFileFormatType("OGG", "ogg");
  
  public VorbisFileFormatType(String paramString1, String paramString2)
  {
    super(paramString1, paramString2);
  }
}
