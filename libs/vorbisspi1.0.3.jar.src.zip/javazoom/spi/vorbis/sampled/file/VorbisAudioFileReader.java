package javazoom.spi.vorbis.sampled.file;

import com.jcraft.jogg.Packet;
import com.jcraft.jogg.Page;
import com.jcraft.jogg.StreamState;
import com.jcraft.jogg.SyncState;
import com.jcraft.jorbis.Block;
import com.jcraft.jorbis.Comment;
import com.jcraft.jorbis.DspState;
import com.jcraft.jorbis.Info;
import com.jcraft.jorbis.JOrbisException;
import com.jcraft.jorbis.VorbisFile;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.StringTokenizer;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat.Encoding;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.UnsupportedAudioFileException;
import org.tritonus.share.TDebug;
import org.tritonus.share.sampled.file.TAudioFileReader;

public class VorbisAudioFileReader
  extends TAudioFileReader
{
  private SyncState oggSyncState_ = null;
  private StreamState oggStreamState_ = null;
  private Page oggPage_ = null;
  private Packet oggPacket_ = null;
  private Info vorbisInfo = null;
  private Comment vorbisComment = null;
  private DspState vorbisDspState = null;
  private Block vorbisBlock = null;
  private int bufferMultiple_ = 4;
  private int bufferSize_ = this.bufferMultiple_ * 256 * 2;
  private byte[] buffer = null;
  private int bytes = 0;
  private int index = 0;
  private InputStream oggBitStream_ = null;
  private static final int INITAL_READ_LENGTH = 64000;
  private static final int MARK_LIMIT = 64001;
  
  public VorbisAudioFileReader()
  {
    super(64001, true);
  }
  
  public AudioFileFormat getAudioFileFormat(File paramFile)
    throws UnsupportedAudioFileException, IOException
  {
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("getAudioFileFormat(File file)");
    }
    BufferedInputStream localBufferedInputStream = null;
    try
    {
      localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramFile));
      localBufferedInputStream.mark(64001);
      AudioFileFormat localAudioFileFormat1 = getAudioFileFormat(localBufferedInputStream);
      localBufferedInputStream.reset();
      VorbisFile localVorbisFile = new VorbisFile(paramFile.getAbsolutePath());
      AudioFileFormat localAudioFileFormat2 = getAudioFileFormat(localBufferedInputStream, (int)paramFile.length(), Math.round(localVorbisFile.time_total(-1) * 1000.0F));
      return localAudioFileFormat2;
    }
    catch (JOrbisException localJOrbisException)
    {
      throw new IOException(localJOrbisException.getMessage());
    }
    finally
    {
      if (localBufferedInputStream != null) {
        localBufferedInputStream.close();
      }
    }
  }
  
  public AudioFileFormat getAudioFileFormat(URL paramURL)
    throws UnsupportedAudioFileException, IOException
  {
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("getAudioFileFormat(URL url)");
    }
    InputStream localInputStream = paramURL.openStream();
    try
    {
      AudioFileFormat localAudioFileFormat = getAudioFileFormat(localInputStream);
      return localAudioFileFormat;
    }
    finally
    {
      if (localInputStream != null) {
        localInputStream.close();
      }
    }
  }
  
  public AudioFileFormat getAudioFileFormat(InputStream paramInputStream)
    throws UnsupportedAudioFileException, IOException
  {
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("getAudioFileFormat(InputStream inputStream)");
    }
    try
    {
      if (!paramInputStream.markSupported()) {
        paramInputStream = new BufferedInputStream(paramInputStream);
      }
      paramInputStream.mark(64001);
      AudioFileFormat localAudioFileFormat = getAudioFileFormat(paramInputStream, -1, -1);
      return localAudioFileFormat;
    }
    finally
    {
      paramInputStream.reset();
    }
  }
  
  public AudioFileFormat getAudioFileFormat(InputStream paramInputStream, long paramLong)
    throws UnsupportedAudioFileException, IOException
  {
    return getAudioFileFormat(paramInputStream, (int)paramLong, -1);
  }
  
  protected AudioFileFormat getAudioFileFormat(InputStream paramInputStream, int paramInt1, int paramInt2)
    throws UnsupportedAudioFileException, IOException
  {
    HashMap localHashMap1 = new HashMap();
    HashMap localHashMap2 = new HashMap();
    if (paramInt2 == -1) {
      paramInt2 = 0;
    }
    if (paramInt2 <= 0) {
      paramInt2 = 0;
    } else {
      localHashMap1.put("duration", new Long(paramInt2 * 1000));
    }
    this.oggBitStream_ = paramInputStream;
    init_jorbis();
    this.index = 0;
    try
    {
      readHeaders(localHashMap1, localHashMap2);
    }
    catch (IOException localIOException)
    {
      if (TDebug.TraceAudioFileReader) {
        TDebug.out(localIOException.getMessage());
      }
      throw new UnsupportedAudioFileException(localIOException.getMessage());
    }
    String str = this.vorbisInfo.toString();
    if (TDebug.TraceAudioFileReader) {
      TDebug.out(str);
    }
    int i = str.lastIndexOf("bitrate:");
    int j = -1;
    int k = -1;
    int m = -1;
    if (i != -1)
    {
      str = str.substring(i + 8, str.length());
      StringTokenizer localStringTokenizer = new StringTokenizer(str, ",");
      if (localStringTokenizer.hasMoreTokens()) {
        j = Integer.parseInt(localStringTokenizer.nextToken());
      }
      if (localStringTokenizer.hasMoreTokens()) {
        k = Integer.parseInt(localStringTokenizer.nextToken());
      }
      if (localStringTokenizer.hasMoreTokens()) {
        m = Integer.parseInt(localStringTokenizer.nextToken());
      }
    }
    if (k > 0) {
      localHashMap2.put("bitrate", new Integer(k));
    }
    localHashMap2.put("vbr", new Boolean(true));
    if (j > 0) {
      localHashMap1.put("ogg.bitrate.min.bps", new Integer(j));
    }
    if (m > 0) {
      localHashMap1.put("ogg.bitrate.max.bps", new Integer(m));
    }
    if (k > 0) {
      localHashMap1.put("ogg.bitrate.nominal.bps", new Integer(k));
    }
    if (this.vorbisInfo.channels > 0) {
      localHashMap1.put("ogg.channels", new Integer(this.vorbisInfo.channels));
    }
    if (this.vorbisInfo.rate > 0) {
      localHashMap1.put("ogg.frequency.hz", new Integer(this.vorbisInfo.rate));
    }
    if (paramInt1 > 0) {
      localHashMap1.put("ogg.length.bytes", new Integer(paramInt1));
    }
    localHashMap1.put("ogg.version", new Integer(this.vorbisInfo.version));
    float f = -1.0F;
    if (k > 0) {
      f = k / 8;
    } else if (j > 0) {
      f = j / 8;
    }
    AudioFormat.Encoding localEncoding = VorbisEncoding.VORBISENC;
    VorbisAudioFormat localVorbisAudioFormat = new VorbisAudioFormat(localEncoding, this.vorbisInfo.rate, -1, this.vorbisInfo.channels, 1, f, false, localHashMap2);
    return new VorbisAudioFileFormat(VorbisFileFormatType.OGG, localVorbisAudioFormat, -1, paramInt1, localHashMap1);
  }
  
  public AudioInputStream getAudioInputStream(InputStream paramInputStream)
    throws UnsupportedAudioFileException, IOException
  {
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("getAudioInputStream(InputStream inputStream)");
    }
    return getAudioInputStream(paramInputStream, -1, -1);
  }
  
  public AudioInputStream getAudioInputStream(InputStream paramInputStream, int paramInt1, int paramInt2)
    throws UnsupportedAudioFileException, IOException
  {
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("getAudioInputStream(InputStream inputStreamint medialength, int totalms)");
    }
    try
    {
      if (!paramInputStream.markSupported()) {
        paramInputStream = new BufferedInputStream(paramInputStream);
      }
      paramInputStream.mark(64001);
      AudioFileFormat localAudioFileFormat = getAudioFileFormat(paramInputStream, paramInt1, paramInt2);
      paramInputStream.reset();
      return new AudioInputStream(paramInputStream, localAudioFileFormat.getFormat(), localAudioFileFormat.getFrameLength());
    }
    catch (UnsupportedAudioFileException localUnsupportedAudioFileException)
    {
      paramInputStream.reset();
      throw localUnsupportedAudioFileException;
    }
    catch (IOException localIOException)
    {
      paramInputStream.reset();
      throw localIOException;
    }
  }
  
  public AudioInputStream getAudioInputStream(File paramFile)
    throws UnsupportedAudioFileException, IOException
  {
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("getAudioInputStream(File file)");
    }
    FileInputStream localFileInputStream = new FileInputStream(paramFile);
    try
    {
      return getAudioInputStream(localFileInputStream);
    }
    catch (UnsupportedAudioFileException localUnsupportedAudioFileException)
    {
      if (localFileInputStream != null) {
        localFileInputStream.close();
      }
      throw localUnsupportedAudioFileException;
    }
    catch (IOException localIOException)
    {
      if (localFileInputStream != null) {
        localFileInputStream.close();
      }
      throw localIOException;
    }
  }
  
  public AudioInputStream getAudioInputStream(URL paramURL)
    throws UnsupportedAudioFileException, IOException
  {
    if (TDebug.TraceAudioFileReader) {
      TDebug.out("getAudioInputStream(URL url)");
    }
    InputStream localInputStream = paramURL.openStream();
    try
    {
      return getAudioInputStream(localInputStream);
    }
    catch (UnsupportedAudioFileException localUnsupportedAudioFileException)
    {
      if (localInputStream != null) {
        localInputStream.close();
      }
      throw localUnsupportedAudioFileException;
    }
    catch (IOException localIOException)
    {
      if (localInputStream != null) {
        localInputStream.close();
      }
      throw localIOException;
    }
  }
  
  private void readHeaders(HashMap paramHashMap1, HashMap paramHashMap2)
    throws IOException
  {
    if (TDebug.TraceAudioConverter) {
      TDebug.out("readHeaders(");
    }
    this.index = this.oggSyncState_.buffer(this.bufferSize_);
    this.buffer = this.oggSyncState_.data;
    this.bytes = readFromStream(this.buffer, this.index, this.bufferSize_);
    if (this.bytes == -1)
    {
      if (TDebug.TraceAudioConverter) {
        TDebug.out("Cannot get any data from selected Ogg bitstream.");
      }
      throw new IOException("Cannot get any data from selected Ogg bitstream.");
    }
    this.oggSyncState_.wrote(this.bytes);
    if (this.oggSyncState_.pageout(this.oggPage_) != 1)
    {
      if (this.bytes < this.bufferSize_) {
        throw new IOException("EOF");
      }
      if (TDebug.TraceAudioConverter) {
        TDebug.out("Input does not appear to be an Ogg bitstream.");
      }
      throw new IOException("Input does not appear to be an Ogg bitstream.");
    }
    this.oggStreamState_.init(this.oggPage_.serialno());
    this.vorbisInfo.init();
    this.vorbisComment.init();
    paramHashMap1.put("ogg.serial", new Integer(this.oggPage_.serialno()));
    if (this.oggStreamState_.pagein(this.oggPage_) < 0)
    {
      if (TDebug.TraceAudioConverter) {
        TDebug.out("Error reading first page of Ogg bitstream data.");
      }
      throw new IOException("Error reading first page of Ogg bitstream data.");
    }
    if (this.oggStreamState_.packetout(this.oggPacket_) != 1)
    {
      if (TDebug.TraceAudioConverter) {
        TDebug.out("Error reading initial header packet.");
      }
      throw new IOException("Error reading initial header packet.");
    }
    if (this.vorbisInfo.synthesis_headerin(this.vorbisComment, this.oggPacket_) < 0)
    {
      if (TDebug.TraceAudioConverter) {
        TDebug.out("This Ogg bitstream does not contain Vorbis audio data.");
      }
      throw new IOException("This Ogg bitstream does not contain Vorbis audio data.");
    }
    int i = 0;
    while (i < 2)
    {
      label438:
      while (i < 2)
      {
        int j = this.oggSyncState_.pageout(this.oggPage_);
        if (j == 0) {
          break;
        }
        if (j == 1)
        {
          this.oggStreamState_.pagein(this.oggPage_);
          for (;;)
          {
            if (i >= 2) {
              break label438;
            }
            j = this.oggStreamState_.packetout(this.oggPacket_);
            if (j == 0) {
              break;
            }
            if (j == -1)
            {
              if (TDebug.TraceAudioConverter) {
                TDebug.out("Corrupt secondary header.  Exiting.");
              }
              throw new IOException("Corrupt secondary header.  Exiting.");
            }
            this.vorbisInfo.synthesis_headerin(this.vorbisComment, this.oggPacket_);
            i++;
          }
        }
      }
      this.index = this.oggSyncState_.buffer(this.bufferSize_);
      this.buffer = this.oggSyncState_.data;
      this.bytes = readFromStream(this.buffer, this.index, this.bufferSize_);
      if (this.bytes == -1) {
        break;
      }
      if ((this.bytes == 0) && (i < 2))
      {
        if (TDebug.TraceAudioConverter) {
          TDebug.out("End of file before finding all Vorbis headers!");
        }
        throw new IOException("End of file before finding all Vorbis  headers!");
      }
      this.oggSyncState_.wrote(this.bytes);
    }
    byte[][] arrayOfByte = this.vorbisComment.user_comments;
    String str = "";
    int k = 0;
    for (int m = 0; (m < arrayOfByte.length) && (arrayOfByte[m] != null); m++)
    {
      str = new String(arrayOfByte[m], 0, arrayOfByte[m].length - 1, "UTF-8").trim();
      if (TDebug.TraceAudioConverter) {
        TDebug.out(str);
      }
      if (str.toLowerCase().startsWith("artist"))
      {
        paramHashMap1.put("author", str.substring(7));
      }
      else if (str.toLowerCase().startsWith("title"))
      {
        paramHashMap1.put("title", str.substring(6));
      }
      else if (str.toLowerCase().startsWith("album"))
      {
        paramHashMap1.put("album", str.substring(6));
      }
      else if (str.toLowerCase().startsWith("date"))
      {
        paramHashMap1.put("date", str.substring(5));
      }
      else if (str.toLowerCase().startsWith("copyright"))
      {
        paramHashMap1.put("copyright", str.substring(10));
      }
      else if (str.toLowerCase().startsWith("comment"))
      {
        paramHashMap1.put("comment", str.substring(8));
      }
      else if (str.toLowerCase().startsWith("genre"))
      {
        paramHashMap1.put("ogg.comment.genre", str.substring(6));
      }
      else if (str.toLowerCase().startsWith("tracknumber"))
      {
        paramHashMap1.put("ogg.comment.track", str.substring(12));
      }
      else
      {
        k++;
        paramHashMap1.put("ogg.comment.ext." + k, str);
      }
      paramHashMap1.put("ogg.comment.encodedby", new String(this.vorbisComment.vendor, 0, this.vorbisComment.vendor.length - 1));
    }
  }
  
  private int readFromStream(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    int i = 0;
    try
    {
      i = this.oggBitStream_.read(paramArrayOfByte, paramInt1, paramInt2);
    }
    catch (Exception localException)
    {
      if (TDebug.TraceAudioFileReader) {
        TDebug.out("Cannot Read Selected Song");
      }
      i = -1;
    }
    return i;
  }
  
  private void init_jorbis()
  {
    this.oggSyncState_ = new SyncState();
    this.oggStreamState_ = new StreamState();
    this.oggPage_ = new Page();
    this.oggPacket_ = new Packet();
    this.vorbisInfo = new Info();
    this.vorbisComment = new Comment();
    this.vorbisDspState = new DspState();
    this.vorbisBlock = new Block(this.vorbisDspState);
    this.buffer = null;
    this.bytes = 0;
    this.oggSyncState_.init();
  }
}
