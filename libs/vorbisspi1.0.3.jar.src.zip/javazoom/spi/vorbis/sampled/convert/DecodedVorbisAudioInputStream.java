package javazoom.spi.vorbis.sampled.convert;

import com.jcraft.jogg.Packet;
import com.jcraft.jogg.Page;
import com.jcraft.jogg.StreamState;
import com.jcraft.jogg.SyncState;
import com.jcraft.jorbis.Block;
import com.jcraft.jorbis.Comment;
import com.jcraft.jorbis.DspState;
import com.jcraft.jorbis.Info;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javazoom.spi.PropertiesContainer;
import org.tritonus.share.TCircularBuffer;
import org.tritonus.share.TDebug;
import org.tritonus.share.sampled.convert.TAsynchronousFilteredAudioInputStream;

public class DecodedVorbisAudioInputStream
  extends TAsynchronousFilteredAudioInputStream
  implements PropertiesContainer
{
  private InputStream oggBitStream_ = null;
  private SyncState oggSyncState_ = null;
  private StreamState oggStreamState_ = null;
  private Page oggPage_ = null;
  private Packet oggPacket_ = null;
  private Info vorbisInfo = null;
  private Comment vorbisComment = null;
  private DspState vorbisDspState = null;
  private Block vorbisBlock = null;
  static final int playState_NeedHeaders = 0;
  static final int playState_ReadData = 1;
  static final int playState_WriteData = 2;
  static final int playState_Done = 3;
  static final int playState_BufferFull = 4;
  static final int playState_Corrupt = -1;
  private int playState;
  private int bufferMultiple_ = 4;
  private int bufferSize_ = this.bufferMultiple_ * 256 * 2;
  private int convsize = this.bufferSize_ * 2;
  private byte[] convbuffer = new byte[this.convsize];
  private byte[] buffer = null;
  private int bytes = 0;
  private float[][][] _pcmf = (float[][][])null;
  private int[] _index = null;
  private int index = 0;
  private int i = 0;
  int bout = 0;
  private HashMap properties = null;
  private long currentBytes = 0L;
  
  public DecodedVorbisAudioInputStream(AudioFormat paramAudioFormat, AudioInputStream paramAudioInputStream)
  {
    super(paramAudioFormat, -1L);
    this.oggBitStream_ = paramAudioInputStream;
    init_jorbis();
    this.index = 0;
    this.playState = 0;
    this.properties = new HashMap();
  }
  
  private void init_jorbis()
  {
    this.oggSyncState_ = new SyncState();
    this.oggStreamState_ = new StreamState();
    this.oggPage_ = new Page();
    this.oggPacket_ = new Packet();
    this.vorbisInfo = new Info();
    this.vorbisComment = new Comment();
    this.vorbisDspState = new DspState();
    this.vorbisBlock = new Block(this.vorbisDspState);
    this.buffer = null;
    this.bytes = 0;
    this.currentBytes = 0L;
    this.oggSyncState_.init();
  }
  
  public Map properties()
  {
    this.properties.put("ogg.position.byte", new Long(this.currentBytes));
    return this.properties;
  }
  
  public void execute()
  {
    if (TDebug.TraceAudioConverter) {
      switch (this.playState)
      {
      case 0: 
        TDebug.out("playState = playState_NeedHeaders");
        break;
      case 1: 
        TDebug.out("playState = playState_ReadData");
        break;
      case 2: 
        TDebug.out("playState = playState_WriteData");
        break;
      case 3: 
        TDebug.out("playState = playState_Done");
        break;
      case 4: 
        TDebug.out("playState = playState_BufferFull");
        break;
      case -1: 
        TDebug.out("playState = playState_Corrupt");
      }
    }
    int j;
    switch (this.playState)
    {
    case 0: 
      try
      {
        readHeaders();
      }
      catch (IOException localIOException)
      {
        this.playState = -1;
        return;
      }
      this.playState = 1;
      break;
    case 1: 
      this.index = this.oggSyncState_.buffer(this.bufferSize_);
      this.buffer = this.oggSyncState_.data;
      this.bytes = readFromStream(this.buffer, this.index, this.bufferSize_);
      if (TDebug.TraceAudioConverter) {
        TDebug.out("More data : " + this.bytes);
      }
      if (this.bytes == -1)
      {
        this.playState = 3;
        if (TDebug.TraceAudioConverter) {
          TDebug.out("Ogg Stream empty. Settings playState to playState_Done.");
        }
      }
      else
      {
        this.oggSyncState_.wrote(this.bytes);
        if (this.bytes == 0)
        {
          if ((this.oggPage_.eos() != 0) || (this.oggStreamState_.e_o_s != 0) || (this.oggPacket_.e_o_s != 0))
          {
            if (TDebug.TraceAudioConverter) {
              TDebug.out("oggSyncState wrote 0 bytes: settings playState to playState_Done.");
            }
            this.playState = 3;
          }
          if (TDebug.TraceAudioConverter) {
            TDebug.out("oggSyncState wrote 0 bytes: but stream not yet empty.");
          }
        }
        else
        {
          j = this.oggSyncState_.pageout(this.oggPage_);
          if (j == 0)
          {
            if (TDebug.TraceAudioConverter) {
              TDebug.out("Setting playState to playState_ReadData.");
            }
            this.playState = 1;
          }
          else if (j == -1)
          {
            if (TDebug.TraceAudioConverter) {
              TDebug.out("Corrupt or missing data in bitstream; setting playState to playState_ReadData");
            }
            this.playState = 1;
          }
          else
          {
            this.oggStreamState_.pagein(this.oggPage_);
            if (TDebug.TraceAudioConverter) {
              TDebug.out("Setting playState to playState_WriteData.");
            }
            this.playState = 2;
          }
        }
      }
      break;
    case 2: 
      if (TDebug.TraceAudioConverter) {
        TDebug.out("Decoding");
      }
      do
      {
        for (;;)
        {
          j = this.oggStreamState_.packetout(this.oggPacket_);
          if (j == 0)
          {
            if (TDebug.TraceAudioConverter) {
              TDebug.out("Packetout returned 0, going to read state.");
            }
            this.playState = 1;
            break label552;
          }
          if (j == -1)
          {
            if (TDebug.TraceAudioConverter) {
              TDebug.out("Corrupt or missing data in packetout bitstream; going to read state...");
            }
          }
          else
          {
            if (this.vorbisBlock.synthesis(this.oggPacket_) == 0)
            {
              this.vorbisDspState.synthesis_blockin(this.vorbisBlock);
              break;
            }
            if (TDebug.TraceAudioConverter) {
              TDebug.out("VorbisBlock.synthesis() returned !0, continuing.");
            }
          }
        }
        outputSamples();
      } while (this.playState != 4);
      return;
      if (this.oggPage_.eos() != 0)
      {
        if (TDebug.TraceAudioConverter) {
          TDebug.out("Settings playState to playState_Done.");
        }
        this.playState = 3;
      }
      break;
    case 4: 
      continueFromBufferFull();
      break;
    case -1: 
      if (TDebug.TraceAudioConverter) {
        TDebug.out("Corrupt Song.");
      }
    case 3: 
      label552:
      this.oggStreamState_.clear();
      this.vorbisBlock.clear();
      this.vorbisDspState.clear();
      this.vorbisInfo.clear();
      this.oggSyncState_.clear();
      if (TDebug.TraceAudioConverter) {
        TDebug.out("Done Song.");
      }
      try
      {
        if (this.oggBitStream_ != null) {
          this.oggBitStream_.close();
        }
        getCircularBuffer().close();
      }
      catch (Exception localException)
      {
        if (TDebug.TraceAudioConverter) {
          TDebug.out(localException.getMessage());
        }
      }
    }
  }
  
  private void outputSamples()
  {
    int j;
    while ((j = this.vorbisDspState.synthesis_pcmout(this._pcmf, this._index)) > 0)
    {
      float[][] arrayOfFloat = this._pcmf[0];
      this.bout = (j < this.convsize ? j : this.convsize);
      double d = 0.0D;
      for (this.i = 0; this.i < this.vorbisInfo.channels; this.i += 1)
      {
        int k = this.i * 2;
        int m = this._index[this.i];
        for (int n = 0; n < this.bout; n++)
        {
          d = arrayOfFloat[this.i][(m + n)] * 32767.0D;
          int i1 = (int)d;
          if (i1 > 32767) {
            i1 = 32767;
          }
          if (i1 < 32768) {
            i1 = 32768;
          }
          if (i1 < 0) {
            i1 |= 0x8000;
          }
          this.convbuffer[k] = ((byte)i1);
          this.convbuffer[(k + 1)] = ((byte)(i1 >>> 8));
          k += 2 * this.vorbisInfo.channels;
        }
      }
      if (TDebug.TraceAudioConverter) {
        TDebug.out("about to write: " + 2 * this.vorbisInfo.channels * this.bout);
      }
      if (getCircularBuffer().availableWrite() < 2 * this.vorbisInfo.channels * this.bout)
      {
        if (TDebug.TraceAudioConverter) {
          TDebug.out("Too much data in this data packet, better return, let the channel drain, and try again...");
        }
        this.playState = 4;
        return;
      }
      getCircularBuffer().write(this.convbuffer, 0, 2 * this.vorbisInfo.channels * this.bout);
      if ((this.bytes < this.bufferSize_) && (TDebug.TraceAudioConverter)) {
        TDebug.out("Finished with final buffer of music?");
      }
      if ((this.vorbisDspState.synthesis_read(this.bout) != 0) && (TDebug.TraceAudioConverter)) {
        TDebug.out("VorbisDspState.synthesis_read returned -1.");
      }
    }
    this.playState = 1;
  }
  
  private void continueFromBufferFull()
  {
    if (getCircularBuffer().availableWrite() < 2 * this.vorbisInfo.channels * this.bout)
    {
      if (TDebug.TraceAudioConverter) {
        TDebug.out("Too much data in this data packet, better return, let the channel drain, and try again...");
      }
      return;
    }
    getCircularBuffer().write(this.convbuffer, 0, 2 * this.vorbisInfo.channels * this.bout);
    outputSamples();
  }
  
  private void readHeaders()
    throws IOException
  {
    if (TDebug.TraceAudioConverter) {
      TDebug.out("readHeaders(");
    }
    this.index = this.oggSyncState_.buffer(this.bufferSize_);
    this.buffer = this.oggSyncState_.data;
    this.bytes = readFromStream(this.buffer, this.index, this.bufferSize_);
    if (this.bytes == -1)
    {
      if (TDebug.TraceAudioConverter) {
        TDebug.out("Cannot get any data from selected Ogg bitstream.");
      }
      throw new IOException("Cannot get any data from selected Ogg bitstream.");
    }
    this.oggSyncState_.wrote(this.bytes);
    if (this.oggSyncState_.pageout(this.oggPage_) != 1)
    {
      if (this.bytes < this.bufferSize_) {
        throw new IOException("EOF");
      }
      if (TDebug.TraceAudioConverter) {
        TDebug.out("Input does not appear to be an Ogg bitstream.");
      }
      throw new IOException("Input does not appear to be an Ogg bitstream.");
    }
    this.oggStreamState_.init(this.oggPage_.serialno());
    this.vorbisInfo.init();
    this.vorbisComment.init();
    if (this.oggStreamState_.pagein(this.oggPage_) < 0)
    {
      if (TDebug.TraceAudioConverter) {
        TDebug.out("Error reading first page of Ogg bitstream data.");
      }
      throw new IOException("Error reading first page of Ogg bitstream data.");
    }
    if (this.oggStreamState_.packetout(this.oggPacket_) != 1)
    {
      if (TDebug.TraceAudioConverter) {
        TDebug.out("Error reading initial header packet.");
      }
      throw new IOException("Error reading initial header packet.");
    }
    if (this.vorbisInfo.synthesis_headerin(this.vorbisComment, this.oggPacket_) < 0)
    {
      if (TDebug.TraceAudioConverter) {
        TDebug.out("This Ogg bitstream does not contain Vorbis audio data.");
      }
      throw new IOException("This Ogg bitstream does not contain Vorbis audio data.");
    }
    this.i = 0;
    while (this.i < 2)
    {
      label430:
      while (this.i < 2)
      {
        int j = this.oggSyncState_.pageout(this.oggPage_);
        if (j == 0) {
          break;
        }
        if (j == 1)
        {
          this.oggStreamState_.pagein(this.oggPage_);
          for (;;)
          {
            if (this.i >= 2) {
              break label430;
            }
            j = this.oggStreamState_.packetout(this.oggPacket_);
            if (j == 0) {
              break;
            }
            if (j == -1)
            {
              if (TDebug.TraceAudioConverter) {
                TDebug.out("Corrupt secondary header.  Exiting.");
              }
              throw new IOException("Corrupt secondary header.  Exiting.");
            }
            this.vorbisInfo.synthesis_headerin(this.vorbisComment, this.oggPacket_);
            this.i += 1;
          }
        }
      }
      this.index = this.oggSyncState_.buffer(this.bufferSize_);
      this.buffer = this.oggSyncState_.data;
      this.bytes = readFromStream(this.buffer, this.index, this.bufferSize_);
      if (this.bytes == -1) {
        break;
      }
      if ((this.bytes == 0) && (this.i < 2))
      {
        if (TDebug.TraceAudioConverter) {
          TDebug.out("End of file before finding all Vorbis headers!");
        }
        throw new IOException("End of file before finding all Vorbis  headers!");
      }
      this.oggSyncState_.wrote(this.bytes);
    }
    byte[][] arrayOfByte = this.vorbisComment.user_comments;
    String str = "";
    for (int k = 0; (k < arrayOfByte.length) && (arrayOfByte[k] != null); k++)
    {
      str = new String(arrayOfByte[k], 0, arrayOfByte[k].length - 1).trim();
      if (TDebug.TraceAudioConverter) {
        TDebug.out("Comment: " + str);
      }
    }
    this.convsize = (this.bufferSize_ / this.vorbisInfo.channels);
    this.vorbisDspState.synthesis_init(this.vorbisInfo);
    this.vorbisBlock.init(this.vorbisDspState);
    this._pcmf = new float[1][][];
    this._index = new int[this.vorbisInfo.channels];
  }
  
  private int readFromStream(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    int j = 0;
    try
    {
      j = this.oggBitStream_.read(paramArrayOfByte, paramInt1, paramInt2);
    }
    catch (Exception localException)
    {
      if (TDebug.TraceAudioConverter) {
        TDebug.out("Cannot Read Selected Song");
      }
      j = -1;
    }
    this.currentBytes += j;
    return j;
  }
  
  public void close()
    throws IOException
  {
    super.close();
    this.oggBitStream_.close();
  }
}
