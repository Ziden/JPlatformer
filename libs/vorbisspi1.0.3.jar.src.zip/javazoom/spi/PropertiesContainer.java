package javazoom.spi;

import java.util.Map;

public abstract interface PropertiesContainer
{
  public abstract Map properties();
}
