package org.tritonus.share;

import java.util.Collection;
import java.util.Iterator;

public class StringHashedSet
  extends ArraySet
{
  public StringHashedSet() {}
  
  public StringHashedSet(Collection c)
  {
    super(c);
  }
  
  public boolean add(Object elem)
  {
    if (elem == null) {
      return false;
    }
    return super.add(elem);
  }
  
  public boolean contains(Object elem)
  {
    if (elem == null) {
      return false;
    }
    String comp = elem.toString();
    Iterator it = iterator();
    while (it.hasNext()) {
      if (comp.equals(it.next().toString())) {
        return true;
      }
    }
    return false;
  }
  
  public Object get(Object elem)
  {
    if (elem == null) {
      return null;
    }
    String comp = elem.toString();
    Iterator it = iterator();
    while (it.hasNext())
    {
      Object thisElem = it.next();
      if (comp.equals(thisElem.toString())) {
        return thisElem;
      }
    }
    return null;
  }
}
