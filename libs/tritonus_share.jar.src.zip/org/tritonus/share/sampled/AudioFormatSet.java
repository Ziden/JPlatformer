package org.tritonus.share.sampled;

import java.util.Collection;
import java.util.Iterator;
import javax.sound.sampled.AudioFormat;
import org.tritonus.share.ArraySet;

public class AudioFormatSet
  extends ArraySet
{
  protected static final AudioFormat[] EMPTY_FORMAT_ARRAY = new AudioFormat[0];
  
  public AudioFormatSet() {}
  
  public AudioFormatSet(Collection c)
  {
    super(c);
  }
  
  public boolean add(Object elem)
  {
    if ((elem == null) || (!(elem instanceof AudioFormat))) {
      return false;
    }
    return super.add(elem);
  }
  
  public boolean contains(Object elem)
  {
    if ((elem == null) || (!(elem instanceof AudioFormat))) {
      return false;
    }
    AudioFormat comp = (AudioFormat)elem;
    Iterator it = iterator();
    while (it.hasNext()) {
      if (AudioFormats.equals(comp, (AudioFormat)it.next())) {
        return true;
      }
    }
    return false;
  }
  
  public Object get(Object elem)
  {
    if ((elem == null) || (!(elem instanceof AudioFormat))) {
      return null;
    }
    AudioFormat comp = (AudioFormat)elem;
    Iterator it = iterator();
    while (it.hasNext())
    {
      AudioFormat thisElem = (AudioFormat)it.next();
      if (AudioFormats.equals(comp, thisElem)) {
        return thisElem;
      }
    }
    return null;
  }
  
  public AudioFormat getAudioFormat(AudioFormat elem)
  {
    return (AudioFormat)get(elem);
  }
  
  public AudioFormat matches(AudioFormat elem)
  {
    if (elem == null) {
      return null;
    }
    Iterator it = iterator();
    while (it.hasNext())
    {
      AudioFormat thisElem = (AudioFormat)it.next();
      if (AudioFormats.matches(elem, thisElem)) {
        return thisElem;
      }
    }
    return null;
  }
  
  public AudioFormat[] toAudioFormatArray()
  {
    return (AudioFormat[])toArray(EMPTY_FORMAT_ARRAY);
  }
  
  public void add(int index, Object element)
  {
    throw new UnsupportedOperationException("unsupported");
  }
  
  public Object set(int index, Object element)
  {
    throw new UnsupportedOperationException("unsupported");
  }
}
