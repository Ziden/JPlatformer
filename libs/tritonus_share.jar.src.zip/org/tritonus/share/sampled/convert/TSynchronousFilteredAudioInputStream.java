package org.tritonus.share.sampled.convert;

import java.io.IOException;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import org.tritonus.share.TDebug;
import org.tritonus.share.sampled.AudioUtils;

public abstract class TSynchronousFilteredAudioInputStream
  extends TAudioInputStream
{
  private AudioInputStream originalStream;
  private AudioFormat originalFormat;
  private int originalFrameSize;
  private int newFrameSize;
  protected byte[] buffer = null;
  private boolean m_bConvertInPlace = false;
  
  public TSynchronousFilteredAudioInputStream(AudioInputStream audioInputStream, AudioFormat newFormat)
  {
    super(audioInputStream, newFormat, audioInputStream.getFrameLength());
    this.originalStream = audioInputStream;
    this.originalFormat = audioInputStream.getFormat();
    this.originalFrameSize = (this.originalFormat.getFrameSize() <= 0 ? 1 : this.originalFormat.getFrameSize());
    
    this.newFrameSize = (getFormat().getFrameSize() <= 0 ? 1 : getFormat().getFrameSize());
    if (TDebug.TraceAudioConverter)
    {
      TDebug.out("TSynchronousFilteredAudioInputStream: original format =" + AudioUtils.format2ShortStr(this.originalFormat));
      
      TDebug.out("TSynchronousFilteredAudioInputStream: converted format=" + AudioUtils.format2ShortStr(getFormat()));
    }
    this.m_bConvertInPlace = false;
  }
  
  protected boolean enableConvertInPlace()
  {
    if (this.newFrameSize >= this.originalFrameSize) {
      this.m_bConvertInPlace = true;
    }
    return this.m_bConvertInPlace;
  }
  
  protected abstract int convert(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2);
  
  protected void convertInPlace(byte[] buffer, int byteOffset, int frameCount)
  {
    throw new RuntimeException("Illegal call to convertInPlace");
  }
  
  public int read()
    throws IOException
  {
    if (this.newFrameSize != 1) {
      throw new IOException("frame size must be 1 to read a single byte");
    }
    byte[] temp = new byte[1];
    int result = read(temp);
    if (result == -1) {
      return -1;
    }
    if (result == 0) {
      return -1;
    }
    return temp[0] & 0xFF;
  }
  
  private void clearBuffer()
  {
    this.buffer = null;
  }
  
  public AudioInputStream getOriginalStream()
  {
    return this.originalStream;
  }
  
  public AudioFormat getOriginalFormat()
  {
    return this.originalFormat;
  }
  
  public int read(byte[] abData, int nOffset, int nLength)
    throws IOException
  {
    int nFrameLength = nLength / this.newFrameSize;
    
    int originalBytes = nFrameLength * this.originalFrameSize;
    if (TDebug.TraceAudioConverter) {
      TDebug.out("> TSynchronousFilteredAIS.read(buffer[" + abData.length + "], " + nOffset + " ," + nLength + " bytes ^=" + nFrameLength + " frames)");
    }
    int nFramesConverted = 0;
    int readOffset;
    byte[] readBuffer;
    int readOffset;
    if (this.m_bConvertInPlace)
    {
      byte[] readBuffer = abData;
      readOffset = nOffset;
    }
    else
    {
      if ((this.buffer == null) || (this.buffer.length < originalBytes)) {
        this.buffer = new byte[originalBytes];
      }
      readBuffer = this.buffer;
      readOffset = 0;
    }
    int nBytesRead = this.originalStream.read(readBuffer, readOffset, originalBytes);
    if (nBytesRead == -1)
    {
      clearBuffer();
      return -1;
    }
    int nFramesRead = nBytesRead / this.originalFrameSize;
    if (TDebug.TraceAudioConverter) {
      TDebug.out("original.read returned " + nBytesRead + " bytes ^=" + nFramesRead + " frames");
    }
    if (this.m_bConvertInPlace)
    {
      convertInPlace(abData, nOffset, nFramesRead);
      nFramesConverted = nFramesRead;
    }
    else
    {
      nFramesConverted = convert(this.buffer, abData, nOffset, nFramesRead);
    }
    if (TDebug.TraceAudioConverter) {
      TDebug.out("< converted " + nFramesConverted + " frames");
    }
    return nFramesConverted * this.newFrameSize;
  }
  
  public long skip(long nSkip)
    throws IOException
  {
    long skipFrames = nSkip / this.newFrameSize;
    long originalSkippedBytes = this.originalStream.skip(skipFrames * this.originalFrameSize);
    long skippedFrames = originalSkippedBytes / this.originalFrameSize;
    return skippedFrames * this.newFrameSize;
  }
  
  public int available()
    throws IOException
  {
    int origAvailFrames = this.originalStream.available() / this.originalFrameSize;
    return origAvailFrames * this.newFrameSize;
  }
  
  public void close()
    throws IOException
  {
    this.originalStream.close();
    clearBuffer();
  }
  
  public void mark(int readlimit)
  {
    int readLimitFrames = readlimit / this.newFrameSize;
    this.originalStream.mark(readLimitFrames * this.originalFrameSize);
  }
  
  public void reset()
    throws IOException
  {
    this.originalStream.reset();
  }
  
  public boolean markSupported()
  {
    return this.originalStream.markSupported();
  }
  
  private int getFrameSize()
  {
    return getFormat().getFrameSize();
  }
}
