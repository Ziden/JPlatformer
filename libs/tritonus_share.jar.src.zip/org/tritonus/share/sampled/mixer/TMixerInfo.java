package org.tritonus.share.sampled.mixer;

import javax.sound.sampled.Mixer.Info;

public class TMixerInfo
  extends Mixer.Info
{
  public TMixerInfo(String a, String b, String c, String d)
  {
    super(a, b, c, d);
  }
}
