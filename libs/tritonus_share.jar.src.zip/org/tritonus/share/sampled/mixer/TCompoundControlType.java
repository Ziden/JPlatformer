package org.tritonus.share.sampled.mixer;

import javax.sound.sampled.CompoundControl.Type;

public class TCompoundControlType
  extends CompoundControl.Type
{
  public TCompoundControlType(String strName)
  {
    super(strName);
  }
}
