package org.tritonus.share.sampled.mixer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.sound.sampled.Control;
import javax.sound.sampled.Control.Type;
import javax.sound.sampled.Line;
import javax.sound.sampled.Line.Info;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineEvent.Type;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.LineUnavailableException;
import org.tritonus.share.TDebug;
import org.tritonus.share.TNotifier;

public abstract class TLine
  implements Line
{
  private static final Control[] EMPTY_CONTROL_ARRAY = new Control[0];
  private Line.Info m_info;
  private boolean m_bOpen;
  private List m_controls;
  private Set m_lineListeners;
  private TMixer m_mixer;
  
  protected TLine(TMixer mixer, Line.Info info)
  {
    setLineInfo(info);
    setOpen(false);
    this.m_controls = new ArrayList();
    this.m_lineListeners = new HashSet();
    this.m_mixer = mixer;
  }
  
  protected TLine(TMixer mixer, Line.Info info, Collection controls)
  {
    this(mixer, info);
    this.m_controls.addAll(controls);
  }
  
  protected TMixer getMixer()
  {
    return this.m_mixer;
  }
  
  public Line.Info getLineInfo()
  {
    return this.m_info;
  }
  
  protected void setLineInfo(Line.Info info)
  {
    if (TDebug.TraceLine) {
      TDebug.out("TLine.setLineInfo(): setting: " + info);
    }
    synchronized (this)
    {
      this.m_info = info;
    }
  }
  
  public void open()
    throws LineUnavailableException
  {
    if (TDebug.TraceLine) {
      TDebug.out("TLine.open(): called");
    }
    if (!isOpen())
    {
      if (TDebug.TraceLine) {
        TDebug.out("TLine.open(): opening");
      }
      openImpl();
      if (getMixer() != null) {
        getMixer().registerOpenLine(this);
      }
      setOpen(true);
    }
    else if (TDebug.TraceLine)
    {
      TDebug.out("TLine.open(): already open");
    }
  }
  
  protected void openImpl()
    throws LineUnavailableException
  {
    if (TDebug.TraceLine) {
      TDebug.out("TLine.openImpl(): called");
    }
  }
  
  public void close()
  {
    if (TDebug.TraceLine) {
      TDebug.out("TLine.close(): called");
    }
    if (isOpen())
    {
      if (TDebug.TraceLine) {
        TDebug.out("TLine.close(): closing");
      }
      if (getMixer() != null) {
        getMixer().unregisterOpenLine(this);
      }
      closeImpl();
      setOpen(false);
    }
    else if (TDebug.TraceLine)
    {
      TDebug.out("TLine.close(): not open");
    }
  }
  
  protected void closeImpl()
  {
    if (TDebug.TraceLine) {
      TDebug.out("TLine.closeImpl(): called");
    }
  }
  
  public boolean isOpen()
  {
    return this.m_bOpen;
  }
  
  protected void setOpen(boolean bOpen)
  {
    if (TDebug.TraceLine) {
      TDebug.out("TLine.setOpen(): called, value: " + bOpen);
    }
    boolean bOldValue = isOpen();
    this.m_bOpen = bOpen;
    if (bOldValue != isOpen()) {
      if (isOpen())
      {
        if (TDebug.TraceLine) {
          TDebug.out("TLine.setOpen(): opened");
        }
        notifyLineEvent(LineEvent.Type.OPEN);
      }
      else
      {
        if (TDebug.TraceLine) {
          TDebug.out("TLine.setOpen(): closed");
        }
        notifyLineEvent(LineEvent.Type.CLOSE);
      }
    }
  }
  
  protected void addControl(Control control)
  {
    synchronized (this.m_controls)
    {
      this.m_controls.add(control);
    }
  }
  
  protected void removeControl(Control control)
  {
    synchronized (this.m_controls)
    {
      this.m_controls.remove(control);
    }
  }
  
  /* Error */
  public Control[] getControls()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 6	org/tritonus/share/sampled/mixer/TLine:m_controls	Ljava/util/List;
    //   4: dup
    //   5: astore_1
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 6	org/tritonus/share/sampled/mixer/TLine:m_controls	Ljava/util/List;
    //   11: getstatic 46	org/tritonus/share/sampled/mixer/TLine:EMPTY_CONTROL_ARRAY	[Ljavax/sound/sampled/Control;
    //   14: invokeinterface 47 2 0
    //   19: checkcast 48	[Ljavax/sound/sampled/Control;
    //   22: aload_1
    //   23: monitorexit
    //   24: areturn
    //   25: astore_2
    //   26: aload_1
    //   27: monitorexit
    //   28: aload_2
    //   29: athrow
    // Line number table:
    //   Java source line #266	-> byte code offset #0
    //   Java source line #268	-> byte code offset #7
    //   Java source line #269	-> byte code offset #25
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	30	0	this	TLine
    //   5	22	1	Ljava/lang/Object;	Object
    //   25	4	2	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	24	25	finally
    //   25	28	25	finally
  }
  
  public Control getControl(Control.Type controlType)
  {
    synchronized (this.m_controls)
    {
      Iterator it = this.m_controls.iterator();
      while (it.hasNext())
      {
        Control control = (Control)it.next();
        if (control.getType().equals(controlType)) {
          return control;
        }
      }
      throw new IllegalArgumentException("no control of type " + controlType);
    }
  }
  
  public boolean isControlSupported(Control.Type controlType)
  {
    try
    {
      return getControl(controlType) != null;
    }
    catch (IllegalArgumentException e)
    {
      if (TDebug.TraceAllExceptions) {
        TDebug.out(e);
      }
    }
    return false;
  }
  
  public void addLineListener(LineListener listener)
  {
    synchronized (this.m_lineListeners)
    {
      this.m_lineListeners.add(listener);
    }
  }
  
  public void removeLineListener(LineListener listener)
  {
    synchronized (this.m_lineListeners)
    {
      this.m_lineListeners.remove(listener);
    }
  }
  
  /* Error */
  private Set getLineListeners()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 9	org/tritonus/share/sampled/mixer/TLine:m_lineListeners	Ljava/util/Set;
    //   4: dup
    //   5: astore_1
    //   6: monitorenter
    //   7: new 7	java/util/HashSet
    //   10: dup
    //   11: aload_0
    //   12: getfield 9	org/tritonus/share/sampled/mixer/TLine:m_lineListeners	Ljava/util/Set;
    //   15: invokespecial 63	java/util/HashSet:<init>	(Ljava/util/Collection;)V
    //   18: aload_1
    //   19: monitorexit
    //   20: areturn
    //   21: astore_2
    //   22: aload_1
    //   23: monitorexit
    //   24: aload_2
    //   25: athrow
    // Line number table:
    //   Java source line #336	-> byte code offset #0
    //   Java source line #338	-> byte code offset #7
    //   Java source line #339	-> byte code offset #21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	26	0	this	TLine
    //   5	18	1	Ljava/lang/Object;	Object
    //   21	4	2	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	20	21	finally
    //   21	24	21	finally
  }
  
  protected void notifyLineEvent(LineEvent.Type type)
  {
    notifyLineEvent(new LineEvent(this, type, -1L));
  }
  
  protected void notifyLineEvent(LineEvent event)
  {
    TNotifier.notifier.addEntry(event, getLineListeners());
  }
}
