package org.tritonus.share.sampled;

import java.util.ArrayList;
import java.util.Random;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioFormat.Encoding;

public class FloatSampleBuffer
{
  private static final boolean LAZY_DEFAULT = true;
  private ArrayList channels = new ArrayList();
  private int sampleCount = 0;
  private int channelCount = 0;
  private float sampleRate = 0.0F;
  private int originalFormatType = 0;
  public static final int DITHER_MODE_AUTOMATIC = 0;
  public static final int DITHER_MODE_ON = 1;
  public static final int DITHER_MODE_OFF = 2;
  private static Random random = null;
  private float ditherBits = 0.8F;
  private boolean doDither = false;
  private int ditherMode = 0;
  private static final int F_8 = 1;
  private static final int F_16 = 2;
  private static final int F_24 = 3;
  private static final int F_32 = 4;
  private static final int F_SAMPLE_WIDTH_MASK = 7;
  private static final int F_SIGNED = 8;
  private static final int F_BIGENDIAN = 16;
  private static final int CT_8S = 9;
  private static final int CT_8U = 1;
  private static final int CT_16SB = 26;
  private static final int CT_16SL = 10;
  private static final int CT_24SB = 27;
  private static final int CT_24SL = 11;
  private static final int CT_32SB = 28;
  private static final int CT_32SL = 12;
  private static final float twoPower7 = 128.0F;
  private static final float twoPower15 = 32768.0F;
  private static final float twoPower23 = 8388608.0F;
  private static final float twoPower31 = 2.14748365E9F;
  private static final float invTwoPower7 = 0.0078125F;
  private static final float invTwoPower15 = 3.0517578E-5F;
  private static final float invTwoPower23 = 1.1920929E-7F;
  private static final float invTwoPower31 = 4.656613E-10F;
  
  public FloatSampleBuffer()
  {
    this(0, 0, 1.0F);
  }
  
  public FloatSampleBuffer(int channelCount, int sampleCount, float sampleRate)
  {
    init(channelCount, sampleCount, sampleRate, true);
  }
  
  public FloatSampleBuffer(byte[] buffer, int offset, int byteCount, AudioFormat format)
  {
    this(format.getChannels(), byteCount / (format.getSampleSizeInBits() / 8 * format.getChannels()), format.getSampleRate());
    
    initFromByteArray(buffer, offset, byteCount, format);
  }
  
  protected void init(int channelCount, int sampleCount, float sampleRate)
  {
    init(channelCount, sampleCount, sampleRate, true);
  }
  
  protected void init(int channelCount, int sampleCount, float sampleRate, boolean lazy)
  {
    if ((channelCount < 0) || (sampleCount < 0)) {
      throw new IllegalArgumentException("Invalid parameters in initialization of FloatSampleBuffer.");
    }
    setSampleRate(sampleRate);
    if ((getSampleCount() != sampleCount) || (getChannelCount() != channelCount)) {
      createChannels(channelCount, sampleCount, lazy);
    }
  }
  
  private void createChannels(int channelCount, int sampleCount, boolean lazy)
  {
    this.sampleCount = sampleCount;
    
    this.channelCount = 0;
    for (int ch = 0; ch < channelCount; ch++) {
      insertChannel(ch, false, lazy);
    }
    if (!lazy) {
      while (this.channels.size() > channelCount) {
        this.channels.remove(this.channels.size() - 1);
      }
    }
  }
  
  public void initFromByteArray(byte[] buffer, int offset, int byteCount, AudioFormat format)
  {
    initFromByteArray(buffer, offset, byteCount, format, true);
  }
  
  public void initFromByteArray(byte[] buffer, int offset, int byteCount, AudioFormat format, boolean lazy)
  {
    if (offset + byteCount > buffer.length) {
      throw new IllegalArgumentException("FloatSampleBuffer.initFromByteArray: buffer too small.");
    }
    boolean signed = format.getEncoding().equals(AudioFormat.Encoding.PCM_SIGNED);
    if ((!signed) && (!format.getEncoding().equals(AudioFormat.Encoding.PCM_UNSIGNED))) {
      throw new IllegalArgumentException("FloatSampleBuffer: only PCM samples are possible.");
    }
    int bytesPerSample = format.getSampleSizeInBits() / 8;
    int bytesPerFrame = bytesPerSample * format.getChannels();
    int thisSampleCount = byteCount / bytesPerFrame;
    init(format.getChannels(), thisSampleCount, format.getSampleRate(), lazy);
    int formatType = getFormatType(format.getSampleSizeInBits(), signed, format.isBigEndian());
    
    this.originalFormatType = formatType;
    for (int ch = 0; ch < format.getChannels(); ch++)
    {
      convertByteToFloat(buffer, offset, bytesPerFrame, formatType, getChannel(ch), 0, this.sampleCount);
      
      offset += bytesPerSample;
    }
  }
  
  public void initFromFloatSampleBuffer(FloatSampleBuffer source)
  {
    init(source.getChannelCount(), source.getSampleCount(), source.getSampleRate());
    for (int ch = 0; ch < getChannelCount(); ch++) {
      System.arraycopy(source.getChannel(ch), 0, getChannel(ch), 0, this.sampleCount);
    }
  }
  
  public void reset()
  {
    init(0, 0, 1.0F, false);
  }
  
  public void reset(int channels, int sampleCount, float sampleRate)
  {
    init(channels, sampleCount, sampleRate, false);
  }
  
  public int getByteArrayBufferSize(AudioFormat format)
  {
    if ((!format.getEncoding().equals(AudioFormat.Encoding.PCM_SIGNED)) && (!format.getEncoding().equals(AudioFormat.Encoding.PCM_UNSIGNED))) {
      throw new IllegalArgumentException("FloatSampleBuffer: only PCM samples are possible.");
    }
    int bytesPerSample = format.getSampleSizeInBits() / 8;
    int bytesPerFrame = bytesPerSample * format.getChannels();
    return bytesPerFrame * getSampleCount();
  }
  
  public int convertToByteArray(byte[] buffer, int offset, AudioFormat format)
  {
    int byteCount = getByteArrayBufferSize(format);
    if (offset + byteCount > buffer.length) {
      throw new IllegalArgumentException("FloatSampleBuffer.convertToByteArray: buffer too small.");
    }
    boolean signed = format.getEncoding().equals(AudioFormat.Encoding.PCM_SIGNED);
    if ((!signed) && (!format.getEncoding().equals(AudioFormat.Encoding.PCM_UNSIGNED))) {
      throw new IllegalArgumentException("FloatSampleBuffer.convertToByteArray: only PCM samples are allowed.");
    }
    if (format.getSampleRate() != getSampleRate()) {
      throw new IllegalArgumentException("FloatSampleBuffer.convertToByteArray: different samplerates.");
    }
    if (format.getChannels() != getChannelCount()) {
      throw new IllegalArgumentException("FloatSampleBuffer.convertToByteArray: different channel count.");
    }
    int bytesPerSample = format.getSampleSizeInBits() / 8;
    int bytesPerFrame = bytesPerSample * format.getChannels();
    int formatType = getFormatType(format.getSampleSizeInBits(), signed, format.isBigEndian());
    for (int ch = 0; ch < format.getChannels(); ch++)
    {
      convertFloatToByte(getChannel(ch), this.sampleCount, buffer, offset, bytesPerFrame, formatType);
      
      offset += bytesPerSample;
    }
    return getSampleCount() * bytesPerFrame;
  }
  
  public byte[] convertToByteArray(AudioFormat format)
  {
    byte[] res = new byte[getByteArrayBufferSize(format)];
    convertToByteArray(res, 0, format);
    return res;
  }
  
  public void changeSampleCount(int newSampleCount, boolean keepOldSamples)
  {
    int oldSampleCount = getSampleCount();
    if (oldSampleCount == newSampleCount) {
      return;
    }
    Object[] oldChannels = null;
    if (keepOldSamples) {
      oldChannels = getAllChannels();
    }
    init(getChannelCount(), newSampleCount, getSampleRate());
    if (keepOldSamples)
    {
      int copyCount = newSampleCount < oldSampleCount ? newSampleCount : oldSampleCount;
      for (int ch = 0; ch < getChannelCount(); ch++)
      {
        float[] oldSamples = (float[])oldChannels[ch];
        float[] newSamples = (float[])getChannel(ch);
        if (oldSamples != newSamples) {
          System.arraycopy(oldSamples, 0, newSamples, 0, copyCount);
        }
        if (oldSampleCount < newSampleCount) {
          for (int i = oldSampleCount; i < newSampleCount; i++) {
            newSamples[i] = 0.0F;
          }
        }
      }
    }
  }
  
  public void makeSilence()
  {
    if (getChannelCount() > 0)
    {
      makeSilence(0);
      for (int ch = 1; ch < getChannelCount(); ch++) {
        copyChannel(0, ch);
      }
    }
  }
  
  public void makeSilence(int channel)
  {
    float[] samples = getChannel(0);
    for (int i = 0; i < getSampleCount(); i++) {
      samples[i] = 0.0F;
    }
  }
  
  public void addChannel(boolean silent)
  {
    insertChannel(getChannelCount(), silent);
  }
  
  public void insertChannel(int index, boolean silent)
  {
    insertChannel(index, silent, true);
  }
  
  public void insertChannel(int index, boolean silent, boolean lazy)
  {
    int physSize = this.channels.size();
    int virtSize = getChannelCount();
    float[] newChannel = null;
    if (physSize > virtSize) {
      for (int ch = virtSize; ch < physSize; ch++)
      {
        float[] thisChannel = (float[])this.channels.get(ch);
        if (((lazy) && (thisChannel.length >= getSampleCount())) || ((!lazy) && (thisChannel.length == getSampleCount())))
        {
          newChannel = thisChannel;
          this.channels.remove(ch);
          break;
        }
      }
    }
    if (newChannel == null) {
      newChannel = new float[getSampleCount()];
    }
    this.channels.add(index, newChannel);
    this.channelCount += 1;
    if (silent) {
      makeSilence(index);
    }
  }
  
  public void removeChannel(int channel)
  {
    removeChannel(channel, true);
  }
  
  public void removeChannel(int channel, boolean lazy)
  {
    if (!lazy) {
      this.channels.remove(channel);
    } else if (channel < getChannelCount() - 1) {
      this.channels.add(this.channels.remove(channel));
    }
    this.channelCount -= 1;
  }
  
  public void copyChannel(int sourceChannel, int targetChannel)
  {
    float[] source = getChannel(sourceChannel);
    float[] target = getChannel(targetChannel);
    System.arraycopy(source, 0, target, 0, getSampleCount());
  }
  
  public void copy(int sourceIndex, int destIndex, int length)
  {
    for (int i = 0; i < getChannelCount(); i++) {
      copy(i, sourceIndex, destIndex, length);
    }
  }
  
  public void copy(int channel, int sourceIndex, int destIndex, int length)
  {
    float[] data = getChannel(channel);
    int bufferCount = getSampleCount();
    if ((sourceIndex + length > bufferCount) || (destIndex + length > bufferCount) || (sourceIndex < 0) || (destIndex < 0) || (length < 0)) {
      throw new IndexOutOfBoundsException("parameters exceed buffer size");
    }
    System.arraycopy(data, sourceIndex, data, destIndex, length);
  }
  
  public void expandChannel(int targetChannelCount)
  {
    if (getChannelCount() != 1) {
      throw new IllegalArgumentException("FloatSampleBuffer: can only expand channels for mono signals.");
    }
    for (int ch = 1; ch < targetChannelCount; ch++)
    {
      addChannel(false);
      copyChannel(0, ch);
    }
  }
  
  public void mixDownChannels()
  {
    float[] firstChannel = getChannel(0);
    int sampleCount = getSampleCount();
    int channelCount = getChannelCount();
    for (int ch = channelCount - 1; ch > 0; ch--)
    {
      float[] thisChannel = getChannel(ch);
      for (int i = 0; i < sampleCount; i++) {
        firstChannel[i] += thisChannel[i];
      }
      removeChannel(ch);
    }
  }
  
  public void setSamplesFromBytes(byte[] srcBuffer, int srcOffset, AudioFormat format, int destOffset, int lengthInSamples)
  {
    int bytesPerSample = (format.getSampleSizeInBits() + 7) / 8;
    int bytesPerFrame = bytesPerSample * format.getChannels();
    if (srcOffset + lengthInSamples * bytesPerFrame > srcBuffer.length) {
      throw new IllegalArgumentException("FloatSampleBuffer.setSamplesFromBytes: srcBuffer too small.");
    }
    if (destOffset + lengthInSamples > getSampleCount()) {
      throw new IllegalArgumentException("FloatSampleBuffer.setSamplesFromBytes: destBuffer too small.");
    }
    boolean signed = format.getEncoding().equals(AudioFormat.Encoding.PCM_SIGNED);
    boolean unsigned = format.getEncoding().equals(AudioFormat.Encoding.PCM_UNSIGNED);
    if ((!signed) && (!unsigned)) {
      throw new IllegalArgumentException("FloatSampleBuffer: only PCM samples are possible.");
    }
    int formatType = getFormatType(format.getSampleSizeInBits(), signed, format.isBigEndian());
    for (int ch = 0; ch < format.getChannels(); ch++)
    {
      convertByteToFloat(srcBuffer, srcOffset, bytesPerFrame, formatType, getChannel(ch), destOffset, lengthInSamples);
      
      srcOffset += bytesPerSample;
    }
  }
  
  public int getChannelCount()
  {
    return this.channelCount;
  }
  
  public int getSampleCount()
  {
    return this.sampleCount;
  }
  
  public float getSampleRate()
  {
    return this.sampleRate;
  }
  
  public void setSampleRate(float sampleRate)
  {
    if (sampleRate <= 0.0F) {
      throw new IllegalArgumentException("Invalid samplerate for FloatSampleBuffer.");
    }
    this.sampleRate = sampleRate;
  }
  
  public float[] getChannel(int channel)
  {
    if ((channel < 0) || (channel >= getChannelCount())) {
      throw new IllegalArgumentException("FloatSampleBuffer: invalid channel number.");
    }
    return (float[])this.channels.get(channel);
  }
  
  public Object[] getAllChannels()
  {
    Object[] res = new Object[getChannelCount()];
    for (int ch = 0; ch < getChannelCount(); ch++) {
      res[ch] = getChannel(ch);
    }
    return res;
  }
  
  public void setDitherBits(float ditherBits)
  {
    if (ditherBits <= 0.0F) {
      throw new IllegalArgumentException("DitherBits must be greater than 0");
    }
    this.ditherBits = ditherBits;
  }
  
  public float getDitherBits()
  {
    return this.ditherBits;
  }
  
  public void setDitherMode(int mode)
  {
    if ((mode != 0) && (mode != 1) && (mode != 2)) {
      throw new IllegalArgumentException("Illegal DitherMode");
    }
    this.ditherMode = mode;
  }
  
  public int getDitherMode()
  {
    return this.ditherMode;
  }
  
  public int getFormatType(int ssib, boolean signed, boolean bigEndian)
  {
    int bytesPerSample = ssib / 8;
    int res = 0;
    if (ssib == 8) {
      res = 1;
    } else if (ssib == 16) {
      res = 2;
    } else if (ssib == 24) {
      res = 3;
    } else if (ssib == 32) {
      res = 4;
    }
    if (res == 0) {
      throw new IllegalArgumentException("FloatSampleBuffer: unsupported sample size of " + ssib + " bits per sample.");
    }
    if ((!signed) && (bytesPerSample > 1)) {
      throw new IllegalArgumentException("FloatSampleBuffer: unsigned samples larger than 8 bit are not supported");
    }
    if (signed) {
      res |= 0x8;
    }
    if ((bigEndian) && (ssib != 8)) {
      res |= 0x10;
    }
    return res;
  }
  
  private static void convertByteToFloat(byte[] input, int inputOffset, int bytesPerFrame, int formatType, float[] output, int outputOffset, int sampleCount)
  {
    int endCount = outputOffset + sampleCount;
    for (int sample = outputOffset; sample < endCount; sample++)
    {
      switch (formatType)
      {
      case 9: 
        output[sample] = (input[inputOffset] * 0.0078125F);
        
        break;
      case 1: 
        output[sample] = (((input[inputOffset] & 0xFF) - 128) * 0.0078125F);
        
        break;
      case 26: 
        output[sample] = ((input[inputOffset] << 8 | input[(inputOffset + 1)] & 0xFF) * 3.0517578E-5F);
        
        break;
      case 10: 
        output[sample] = ((input[(inputOffset + 1)] << 8 | input[inputOffset] & 0xFF) * 3.0517578E-5F);
        
        break;
      case 27: 
        output[sample] = ((input[inputOffset] << 16 | (input[(inputOffset + 1)] & 0xFF) << 8 | input[(inputOffset + 2)] & 0xFF) * 1.1920929E-7F);
        
        break;
      case 11: 
        output[sample] = ((input[(inputOffset + 2)] << 16 | (input[(inputOffset + 1)] & 0xFF) << 8 | input[inputOffset] & 0xFF) * 1.1920929E-7F);
        
        break;
      case 28: 
        output[sample] = ((input[inputOffset] << 24 | (input[(inputOffset + 1)] & 0xFF) << 16 | (input[(inputOffset + 2)] & 0xFF) << 8 | input[(inputOffset + 3)] & 0xFF) * 4.656613E-10F);
        
        break;
      case 12: 
        output[sample] = ((input[(inputOffset + 3)] << 24 | (input[(inputOffset + 2)] & 0xFF) << 16 | (input[(inputOffset + 1)] & 0xFF) << 8 | input[inputOffset] & 0xFF) * 4.656613E-10F);
        
        break;
      case 2: 
      case 3: 
      case 4: 
      case 5: 
      case 6: 
      case 7: 
      case 8: 
      case 13: 
      case 14: 
      case 15: 
      case 16: 
      case 17: 
      case 18: 
      case 19: 
      case 20: 
      case 21: 
      case 22: 
      case 23: 
      case 24: 
      case 25: 
      default: 
        throw new IllegalArgumentException("Unsupported formatType=" + formatType);
      }
      inputOffset += bytesPerFrame;
    }
  }
  
  protected byte quantize8(float sample)
  {
    if (this.doDither) {
      sample += random.nextFloat() * this.ditherBits;
    }
    if (sample >= 127.0F) {
      return Byte.MAX_VALUE;
    }
    if (sample <= -128.0F) {
      return Byte.MIN_VALUE;
    }
    return (byte)(int)(sample < 0.0F ? sample - 0.5F : sample + 0.5F);
  }
  
  protected int quantize16(float sample)
  {
    if (this.doDither) {
      sample += random.nextFloat() * this.ditherBits;
    }
    if (sample >= 32767.0F) {
      return 32767;
    }
    if (sample <= -32768.0F) {
      return 32768;
    }
    return (int)(sample < 0.0F ? sample - 0.5F : sample + 0.5F);
  }
  
  protected int quantize24(float sample)
  {
    if (this.doDither) {
      sample += random.nextFloat() * this.ditherBits;
    }
    if (sample >= 8388607.0F) {
      return 8388607;
    }
    if (sample <= -8388608.0F) {
      return -8388608;
    }
    return (int)(sample < 0.0F ? sample - 0.5F : sample + 0.5F);
  }
  
  protected int quantize32(float sample)
  {
    if (this.doDither) {
      sample += random.nextFloat() * this.ditherBits;
    }
    if (sample >= 2.14748365E9F) {
      return Integer.MAX_VALUE;
    }
    if (sample <= -2.14748365E9F) {
      return Integer.MIN_VALUE;
    }
    return (int)(sample < 0.0F ? sample - 0.5F : sample + 0.5F);
  }
  
  private void convertFloatToByte(float[] input, int sampleCount, byte[] output, int offset, int bytesPerFrame, int formatType)
  {
    switch (this.ditherMode)
    {
    case 0: 
      this.doDither = ((this.originalFormatType & 0x7) > (formatType & 0x7));
      
      break;
    case 1: 
      this.doDither = true;
      break;
    case 2: 
      this.doDither = false;
    }
    if ((this.doDither) && (random == null)) {
      random = new Random();
    }
    for (int inIndex = 0; inIndex < sampleCount; inIndex++)
    {
      switch (formatType)
      {
      case 9: 
        output[offset] = quantize8(input[inIndex] * 128.0F);
        break;
      case 1: 
        output[offset] = ((byte)(quantize8(input[inIndex] * 128.0F) + 128));
        break;
      case 26: 
        int iSample = quantize16(input[inIndex] * 32768.0F);
        output[offset] = ((byte)(iSample >> 8));
        output[(offset + 1)] = ((byte)(iSample & 0xFF));
        break;
      case 10: 
        int iSample = quantize16(input[inIndex] * 32768.0F);
        output[(offset + 1)] = ((byte)(iSample >> 8));
        output[offset] = ((byte)(iSample & 0xFF));
        break;
      case 27: 
        int iSample = quantize24(input[inIndex] * 8388608.0F);
        output[offset] = ((byte)(iSample >> 16));
        output[(offset + 1)] = ((byte)(iSample >>> 8 & 0xFF));
        output[(offset + 2)] = ((byte)(iSample & 0xFF));
        break;
      case 11: 
        int iSample = quantize24(input[inIndex] * 8388608.0F);
        output[(offset + 2)] = ((byte)(iSample >> 16));
        output[(offset + 1)] = ((byte)(iSample >>> 8 & 0xFF));
        output[offset] = ((byte)(iSample & 0xFF));
        break;
      case 28: 
        int iSample = quantize32(input[inIndex] * 2.14748365E9F);
        output[offset] = ((byte)(iSample >> 24));
        output[(offset + 1)] = ((byte)(iSample >>> 16 & 0xFF));
        output[(offset + 2)] = ((byte)(iSample >>> 8 & 0xFF));
        output[(offset + 3)] = ((byte)(iSample & 0xFF));
        break;
      case 12: 
        int iSample = quantize32(input[inIndex] * 2.14748365E9F);
        output[(offset + 3)] = ((byte)(iSample >> 24));
        output[(offset + 2)] = ((byte)(iSample >>> 16 & 0xFF));
        output[(offset + 1)] = ((byte)(iSample >>> 8 & 0xFF));
        output[offset] = ((byte)(iSample & 0xFF));
        break;
      case 2: 
      case 3: 
      case 4: 
      case 5: 
      case 6: 
      case 7: 
      case 8: 
      case 13: 
      case 14: 
      case 15: 
      case 16: 
      case 17: 
      case 18: 
      case 19: 
      case 20: 
      case 21: 
      case 22: 
      case 23: 
      case 24: 
      case 25: 
      default: 
        throw new IllegalArgumentException("Unsupported formatType=" + formatType);
      }
      offset += bytesPerFrame;
    }
  }
  
  private static String formatType2Str(int formatType)
  {
    String res = "" + formatType + ": ";
    switch (formatType & 0x7)
    {
    case 1: 
      res = res + "8bit";
      break;
    case 2: 
      res = res + "16bit";
      break;
    case 3: 
      res = res + "24bit";
      break;
    case 4: 
      res = res + "32bit";
    }
    res = res + ((formatType & 0x8) == 8 ? " signed" : " unsigned");
    if ((formatType & 0x7) != 1) {
      res = res + ((formatType & 0x10) == 16 ? " big endian" : " little endian");
    }
    return res;
  }
}
