package org.tritonus.share.midi;

import java.io.IOException;
import java.io.InputStream;
import java.util.BitSet;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import javax.sound.midi.ControllerEventListener;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MetaEventListener;
import javax.sound.midi.MetaMessage;
import javax.sound.midi.MidiDevice.Info;
import javax.sound.midi.MidiMessage;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;
import javax.sound.midi.Sequencer.SyncMode;
import javax.sound.midi.ShortMessage;
import org.tritonus.share.ArraySet;
import org.tritonus.share.TDebug;

public abstract class TSequencer
  extends TMidiDevice
  implements Sequencer
{
  private static final float MPQ_BPM_FACTOR = 6.0E7F;
  private static final Sequencer.SyncMode[] EMPTY_SYNCMODE_ARRAY = new Sequencer.SyncMode[0];
  private boolean m_bRunning;
  private Sequence m_sequence;
  private Set m_metaListeners;
  private Set[] m_aControllerListeners;
  private float m_fNominalTempoInMPQ;
  private float m_fTempoFactor;
  private Collection m_masterSyncModes;
  private Collection m_slaveSyncModes;
  private Sequencer.SyncMode m_masterSyncMode;
  private Sequencer.SyncMode m_slaveSyncMode;
  private BitSet m_muteBitSet;
  private BitSet m_soloBitSet;
  private BitSet m_enabledBitSet;
  
  protected TSequencer(MidiDevice.Info info, Collection masterSyncModes, Collection slaveSyncModes)
  {
    super(info);
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.<init>(): begin");
    }
    this.m_bRunning = false;
    this.m_sequence = null;
    this.m_metaListeners = new ArraySet();
    this.m_aControllerListeners = new Set[''];
    setTempoInMPQ(500000.0F);
    setTempoFactor(1.0F);
    this.m_masterSyncModes = masterSyncModes;
    this.m_slaveSyncModes = slaveSyncModes;
    if (getMasterSyncModes().length > 0) {
      this.m_masterSyncMode = getMasterSyncModes()[0];
    }
    if (getSlaveSyncModes().length > 0) {
      this.m_slaveSyncMode = getSlaveSyncModes()[0];
    }
    this.m_muteBitSet = new BitSet();
    this.m_soloBitSet = new BitSet();
    this.m_enabledBitSet = new BitSet();
    updateEnabled();
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.<init>(): end");
    }
  }
  
  public void setSequence(Sequence sequence)
    throws InvalidMidiDataException
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setSequence(Sequence): begin");
    }
    this.m_sequence = sequence;
    
    setTempoFactor(1.0F);
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setSequence(Sequence): end");
    }
  }
  
  public void setSequence(InputStream inputStream)
    throws InvalidMidiDataException, IOException
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setSequence(InputStream): begin");
    }
    Sequence sequence = MidiSystem.getSequence(inputStream);
    setSequence(sequence);
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setSequence(InputStream): end");
    }
  }
  
  public Sequence getSequence()
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getSequence(): begin");
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getSequence(): end");
    }
    return this.m_sequence;
  }
  
  public synchronized void start()
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.start(): begin");
    }
    checkOpen();
    if (!isRunning())
    {
      this.m_bRunning = true;
      
      startImpl();
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.start(): end");
    }
  }
  
  protected void startImpl()
  {
    if (TDebug.TraceMidiDevice) {
      TDebug.out("TSequencer.startImpl(): begin");
    }
    if (TDebug.TraceMidiDevice) {
      TDebug.out("TSequencer.startImpl(): end");
    }
  }
  
  public synchronized void stop()
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.stop(): begin");
    }
    checkOpen();
    if (isRunning())
    {
      stopImpl();
      this.m_bRunning = false;
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.stop(): end");
    }
  }
  
  protected void stopImpl()
  {
    if (TDebug.TraceMidiDevice) {
      TDebug.out("TSequencer.stopImpl(): begin");
    }
    if (TDebug.TraceMidiDevice) {
      TDebug.out("TSequencer.stopImpl(): end");
    }
  }
  
  public synchronized boolean isRunning()
  {
    return this.m_bRunning;
  }
  
  protected void checkOpen()
  {
    if (!isOpen()) {
      throw new IllegalStateException("Sequencer is not open");
    }
  }
  
  protected int getResolution()
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getResolution(): begin");
    }
    Sequence sequence = getSequence();
    int nResolution;
    int nResolution;
    if (sequence != null) {
      nResolution = sequence.getResolution();
    } else {
      nResolution = 1;
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getResolution(): end");
    }
    return nResolution;
  }
  
  protected void setRealTempo()
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setRealTempo(): begin");
    }
    float fRealTempo = getTempoInMPQ() / getTempoFactor();
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setRealTempo(): real tempo: " + fRealTempo);
    }
    setTempoImpl(fRealTempo);
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setRealTempo(): end");
    }
  }
  
  public float getTempoInBPM()
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getTempoInBPM(): begin");
    }
    float fBPM = 6.0E7F / getTempoInMPQ();
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getTempoInBPM(): end");
    }
    return fBPM;
  }
  
  public void setTempoInBPM(float fBPM)
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setTempoInBPM(): begin");
    }
    float fMPQ = 6.0E7F / fBPM;
    setTempoInMPQ(fMPQ);
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setTempoInBPM(): end");
    }
  }
  
  public float getTempoInMPQ()
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getTempoInMPQ(): begin");
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getTempoInMPQ(): end");
    }
    return this.m_fNominalTempoInMPQ;
  }
  
  public void setTempoInMPQ(float fMPQ)
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setTempoInMPQ(): begin");
    }
    this.m_fNominalTempoInMPQ = fMPQ;
    setRealTempo();
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setTempoInMPQ(): end");
    }
  }
  
  public void setTempoFactor(float fFactor)
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setTempoFactor(): begin");
    }
    this.m_fTempoFactor = fFactor;
    setRealTempo();
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setTempoFactor(): end");
    }
  }
  
  public float getTempoFactor()
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getTempoFactor(): begin");
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getTempoFactor(): end");
    }
    return this.m_fTempoFactor;
  }
  
  protected abstract void setTempoImpl(float paramFloat);
  
  public long getTickLength()
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getTickLength(): begin");
    }
    long lLength = 0L;
    if (getSequence() != null) {
      lLength = getSequence().getTickLength();
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getTickLength(): end");
    }
    return lLength;
  }
  
  public long getMicrosecondLength()
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getMicrosecondLength(): begin");
    }
    long lLength = 0L;
    if (getSequence() != null) {
      lLength = getSequence().getMicrosecondLength();
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getMicrosecondLength(): end");
    }
    return lLength;
  }
  
  /* Error */
  public boolean addMetaEventListener(MetaEventListener listener)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 9	org/tritonus/share/midi/TSequencer:m_metaListeners	Ljava/util/Set;
    //   4: dup
    //   5: astore_2
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 9	org/tritonus/share/midi/TSequencer:m_metaListeners	Ljava/util/Set;
    //   11: aload_1
    //   12: invokeinterface 90 2 0
    //   17: aload_2
    //   18: monitorexit
    //   19: ireturn
    //   20: astore_3
    //   21: aload_2
    //   22: monitorexit
    //   23: aload_3
    //   24: athrow
    // Line number table:
    //   Java source line #374	-> byte code offset #0
    //   Java source line #376	-> byte code offset #7
    //   Java source line #377	-> byte code offset #20
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	25	0	this	TSequencer
    //   0	25	1	listener	MetaEventListener
    //   5	17	2	Ljava/lang/Object;	Object
    //   20	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	19	20	finally
    //   20	23	20	finally
  }
  
  public void removeMetaEventListener(MetaEventListener listener)
  {
    synchronized (this.m_metaListeners)
    {
      this.m_metaListeners.remove(listener);
    }
  }
  
  /* Error */
  protected Iterator getMetaEventListeners()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 9	org/tritonus/share/midi/TSequencer:m_metaListeners	Ljava/util/Set;
    //   4: dup
    //   5: astore_1
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield 9	org/tritonus/share/midi/TSequencer:m_metaListeners	Ljava/util/Set;
    //   11: invokeinterface 92 1 0
    //   16: aload_1
    //   17: monitorexit
    //   18: areturn
    //   19: astore_2
    //   20: aload_1
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    // Line number table:
    //   Java source line #393	-> byte code offset #0
    //   Java source line #395	-> byte code offset #7
    //   Java source line #396	-> byte code offset #19
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	24	0	this	TSequencer
    //   5	16	1	Ljava/lang/Object;	Object
    //   19	4	2	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   7	18	19	finally
    //   19	22	19	finally
  }
  
  protected void sendMetaMessage(MetaMessage message)
  {
    Iterator iterator = getMetaEventListeners();
    while (iterator.hasNext())
    {
      MetaEventListener metaEventListener = (MetaEventListener)iterator.next();
      MetaMessage copiedMessage = (MetaMessage)message.clone();
      metaEventListener.meta(copiedMessage);
    }
  }
  
  public int[] addControllerEventListener(ControllerEventListener listener, int[] anControllers)
  {
    synchronized (this.m_aControllerListeners)
    {
      if (anControllers == null) {
        for (int i = 0; i < 128; i++) {
          addControllerListener(i, listener);
        }
      } else {
        for (int i = 0; i < anControllers.length; i++) {
          addControllerListener(anControllers[i], listener);
        }
      }
    }
    return getListenedControllers(listener);
  }
  
  private void addControllerListener(int i, ControllerEventListener listener)
  {
    if (this.m_aControllerListeners[i] == null) {
      this.m_aControllerListeners[i] = new ArraySet();
    }
    this.m_aControllerListeners[i].add(listener);
  }
  
  public int[] removeControllerEventListener(ControllerEventListener listener, int[] anControllers)
  {
    synchronized (this.m_aControllerListeners)
    {
      if (anControllers == null) {
        for (int i = 0; i < 128; i++) {
          removeControllerListener(i, listener);
        }
      } else {
        for (int i = 0; i < anControllers.length; i++) {
          removeControllerListener(anControllers[i], listener);
        }
      }
    }
    return getListenedControllers(listener);
  }
  
  private void removeControllerListener(int i, ControllerEventListener listener)
  {
    if (this.m_aControllerListeners[i] != null) {
      this.m_aControllerListeners[i].add(listener);
    }
  }
  
  private int[] getListenedControllers(ControllerEventListener listener)
  {
    int[] anControllers = new int[''];
    int nIndex = 0;
    for (int nController = 0; nController < 128; nController++) {
      if ((this.m_aControllerListeners[nController] != null) && (this.m_aControllerListeners[nController].contains(listener)))
      {
        anControllers[nIndex] = nController;
        nIndex++;
      }
    }
    int[] anResultControllers = new int[nIndex];
    System.arraycopy(anControllers, 0, anResultControllers, 0, nIndex);
    return anResultControllers;
  }
  
  protected void sendControllerEvent(ShortMessage message)
  {
    int nController = message.getData1();
    if (this.m_aControllerListeners[nController] != null)
    {
      Iterator iterator = this.m_aControllerListeners[nController].iterator();
      while (iterator.hasNext())
      {
        ControllerEventListener controllerEventListener = (ControllerEventListener)iterator.next();
        ShortMessage copiedMessage = (ShortMessage)message.clone();
        controllerEventListener.controlChange(copiedMessage);
      }
    }
  }
  
  protected void notifyListeners(MidiMessage message)
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.sendToListeners(): begin");
    }
    if ((message instanceof MetaMessage)) {
      sendMetaMessage((MetaMessage)message);
    } else if (((message instanceof ShortMessage)) && (((ShortMessage)message).getCommand() == 176)) {
      sendControllerEvent((ShortMessage)message);
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.sendToListeners(): end");
    }
  }
  
  public Sequencer.SyncMode getMasterSyncMode()
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getMasterSyncMode(): begin");
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getMasterSyncMode(): end");
    }
    return this.m_masterSyncMode;
  }
  
  public void setMasterSyncMode(Sequencer.SyncMode syncMode)
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setMasterSyncMode(): begin");
    }
    if (this.m_masterSyncModes.contains(syncMode))
    {
      if (!getMasterSyncMode().equals(syncMode))
      {
        this.m_masterSyncMode = syncMode;
        setMasterSyncModeImpl(syncMode);
      }
    }
    else {
      throw new IllegalArgumentException("sync mode not allowed: " + syncMode);
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setMasterSyncMode(): end");
    }
  }
  
  protected void setMasterSyncModeImpl(Sequencer.SyncMode syncMode)
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setMasterSyncModeImpl(): begin");
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setMasterSyncModeImpl(): end");
    }
  }
  
  public Sequencer.SyncMode[] getMasterSyncModes()
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getMasterSyncModes(): begin");
    }
    Sequencer.SyncMode[] syncModes = (Sequencer.SyncMode[])this.m_masterSyncModes.toArray(EMPTY_SYNCMODE_ARRAY);
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getMasterSyncModes(): end");
    }
    return syncModes;
  }
  
  public Sequencer.SyncMode getSlaveSyncMode()
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getSlaveSyncMode(): begin");
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getSlaveSyncMode(): end");
    }
    return this.m_slaveSyncMode;
  }
  
  public void setSlaveSyncMode(Sequencer.SyncMode syncMode)
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setSlaveSyncMode(): begin");
    }
    if (this.m_slaveSyncModes.contains(syncMode))
    {
      if (!getSlaveSyncMode().equals(syncMode))
      {
        this.m_slaveSyncMode = syncMode;
        setSlaveSyncModeImpl(syncMode);
      }
    }
    else {
      throw new IllegalArgumentException("sync mode not allowed: " + syncMode);
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setSlaveSyncMode(): end");
    }
  }
  
  protected void setSlaveSyncModeImpl(Sequencer.SyncMode syncMode)
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setSlaveSyncModeImpl(): begin");
    }
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.setSlaveSyncModeImpl(): end");
    }
  }
  
  public Sequencer.SyncMode[] getSlaveSyncModes()
  {
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getSlaveSyncModes(): begin");
    }
    Sequencer.SyncMode[] syncModes = (Sequencer.SyncMode[])this.m_slaveSyncModes.toArray(EMPTY_SYNCMODE_ARRAY);
    if (TDebug.TraceSequencer) {
      TDebug.out("TSequencer.getSlaveSyncModes(): end");
    }
    return syncModes;
  }
  
  public boolean getTrackSolo(int nTrack)
  {
    boolean bSoloed = false;
    if (getSequence() != null) {
      if (nTrack < getSequence().getTracks().length) {
        bSoloed = this.m_soloBitSet.get(nTrack);
      }
    }
    return bSoloed;
  }
  
  public void setTrackSolo(int nTrack, boolean bSolo)
  {
    if (getSequence() != null) {
      if (nTrack < getSequence().getTracks().length)
      {
        boolean bOldState = this.m_soloBitSet.get(nTrack);
        if (bSolo != bOldState)
        {
          if (bSolo) {
            this.m_soloBitSet.set(nTrack);
          } else {
            this.m_soloBitSet.clear(nTrack);
          }
          updateEnabled();
          setTrackSoloImpl(nTrack, bSolo);
        }
      }
    }
  }
  
  protected void setTrackSoloImpl(int nTrack, boolean bSolo) {}
  
  public boolean getTrackMute(int nTrack)
  {
    boolean bMuted = false;
    if (getSequence() != null) {
      if (nTrack < getSequence().getTracks().length) {
        bMuted = this.m_muteBitSet.get(nTrack);
      }
    }
    return bMuted;
  }
  
  public void setTrackMute(int nTrack, boolean bMute)
  {
    if (getSequence() != null) {
      if (nTrack < getSequence().getTracks().length)
      {
        boolean bOldState = this.m_muteBitSet.get(nTrack);
        if (bMute != bOldState)
        {
          if (bMute) {
            this.m_muteBitSet.set(nTrack);
          } else {
            this.m_muteBitSet.clear(nTrack);
          }
          updateEnabled();
          setTrackMuteImpl(nTrack, bMute);
        }
      }
    }
  }
  
  protected void setTrackMuteImpl(int nTrack, boolean bMute) {}
  
  private void updateEnabled()
  {
    BitSet oldEnabledBitSet = (BitSet)this.m_enabledBitSet.clone();
    boolean bSoloExists = this.m_soloBitSet.length() > 0;
    if (bSoloExists) {
      this.m_enabledBitSet = ((BitSet)this.m_soloBitSet.clone());
    } else {
      for (int i = 0; i < this.m_muteBitSet.size(); i++) {
        if (this.m_muteBitSet.get(i)) {
          this.m_enabledBitSet.clear(i);
        } else {
          this.m_enabledBitSet.set(i);
        }
      }
    }
    oldEnabledBitSet.xor(this.m_enabledBitSet);
    for (int i = 0; i < oldEnabledBitSet.size(); i++) {
      if (oldEnabledBitSet.get(i)) {
        setTrackEnabledImpl(i, this.m_enabledBitSet.get(i));
      }
    }
  }
  
  protected void setTrackEnabledImpl(int nTrack, boolean bEnabled) {}
  
  protected boolean isTrackEnabled(int nTrack)
  {
    return this.m_enabledBitSet.get(nTrack);
  }
  
  public void setLatency(int nMilliseconds) {}
  
  public int getLatency()
  {
    return -1;
  }
}
